function togglePassword() {
  const password = document.getElementById("password");
  const toggle = document.querySelector(".toggle");

  if (password.type === "password") {
    password.type = "text";
    toggle.textContent = "Hide";
  } else {
    password.type = "password";
    toggle.textContent = "Show";
  }
}

function login() {
  const email = document.getElementById("email");
  const password = document.getElementById("password");

  const emailError = document.getElementById("emailError");
  const passwordError = document.getElementById("passwordError");

  let isValid = true;

  // Reset
  emailError.textContent = "";
  passwordError.textContent = "";
  email.classList.remove("error-input", "success-input");
  password.classList.remove("error-input", "success-input");

  // Email validation
  const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  if (email.value.trim() === "") {
    emailError.textContent = "Email is required";
    email.classList.add("error-input");
    isValid = false;
  } else if (!emailPattern.test(email.value)) {
    emailError.textContent = "Enter a valid email";
    email.classList.add("error-input");
    isValid = false;
  } else {
    email.classList.add("success-input");
  }

  // Password validation
  if (password.value.trim() === "") {
    passwordError.textContent = "Password is required";
    password.classList.add("error-input");
    isValid = false;
  } else if (password.value.length <6) {
    passwordError.textContent = "Minimum 6 characters";
    password.classList.add("error-input");
    isValid = false;
  } else {
    password.classList.add("success-input");
  }

  // Final check
  if (isValid) {
    alert("Login successful!");
  }
}

function toggleTheme() {
  const body = document.body;
  const toggle = document.querySelector(".theme-toggle");

  body.classList.toggle("light");

  if (body.classList.contains("light")) {
    toggle.textContent = "☀️";
    localStorage.setItem("theme", "light");
  } else {
    toggle.textContent = "🌙";
    localStorage.setItem("theme", "dark");
  }
}

// Load saved theme
window.onload = () => {
  const savedTheme = localStorage.getItem("theme");
  const toggle = document.querySelector(".theme-toggle");

  if (savedTheme === "light") {
    document.body.classList.add("light");
    toggle.textContent = "☀️";
  }
};